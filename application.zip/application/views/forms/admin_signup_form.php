<?php
$this->load->view('forms/user_signup_form');
?>
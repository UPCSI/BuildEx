<h1> Home </h1>
<h2> Log-in </h2>

<?php $this->load->view('forms/login_form'); ?>

<br>
<a href = "<?php echo site_url('signup'); ?>"> Sign-up </a>
<!DOCTYPE html>
<html lang = "en">
<head>
<title> BuildEx|<?php echo $title ?> </title>
</head>

<body>
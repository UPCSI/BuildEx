<?php

$this->load->view('templates/main_header',$title);

$this->load->view('home_body');

$this->load->view('templates/main_footer');

?>
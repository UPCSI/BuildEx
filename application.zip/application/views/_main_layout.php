<?php

$this->load->view('templates/main_header',$title);

$this->load->view($main_content);

$this->load->view('templates/main_footer');

?>